Here are a few projects that are built on tf.vision. They are build and maintain
by different parties. They can be used as examples of how to build your own
projects based on tf.vision.
