This directory contains the new design of TF model garden vision framework.
Stay tuned.
